let input = document.querySelector("#input");
let resultArea = document.querySelector(".result");
const API_SEARCH = `https://en.wikipedia.org/w/api.php?origin=*&action=opensearch&limit=10&format=json&search=`;
const API_THUMBNAIL = `https://en.wikipedia.org/w/api.php?origin=*&action=query&prop=pageprops|pageimages&format=json&titles=`;

function getData(url, callback) {
  let xhr = new XMLHttpRequest();
  xhr.open("GET", url);
  xhr.send();
  xhr.onload = function () {
    if (this.status === 200) {
      callback(undefined, JSON.parse(this.responseText));
    } else {
      callback(new Error(), undefined);
    }
  };
}
function getDataPromise(url) {
  return new Promise(function (resolve, reject) {
    getData(url, function (err, data) {
      if (err) {
        reject(err);
        return;
      }
      resolve(data);
    });
  });
}

async function getDataWikiAsync() {
  try {
    let titleVal = await getDataPromise(`${API_SEARCH}${input.value}`);

    let result = [];

    if (titleVal[1]) {
      let descVal = await Promise.all(
        titleVal[1].map((user) => getDataPromise(`${API_THUMBNAIL}${user}`))
      );

      descVal.forEach((value, i) => {
        let thumbnail =
          value.query.pages[Object.keys(value.query.pages)].thumbnail?.source;
        // console.log(thumbnail);
        let desc =
          value.query.pages[Object.keys(value.query.pages)[0]].pageprops?.[
            "wikibase-shortdesc"
          ];

        // console.log(desc);
        result.push({
          thumbnail: thumbnail,
          description: desc,
          title: titleVal[1][i],
          link: titleVal[3][i],
        });
      });
    }

    // console.log(result);
    renderData(result);
  } catch (err) {
    console.error(err);
  }
}

function renderData(arr) {
  console.log(arr);
  let html = "";
  arr.map((value) => {
    html += `
    <a href="${value.link}"  class="result__item" target="_blank">
    <div class="p-0 me-3">
    <img src="${
      value.thumbnail ||
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQvNJYG5M1LCfNbTvM6frlwIzRrVM9Vayyk3g-0gXze8EEwGtaFvldLi-QFBSY4kABxlY&usqp=CAU"
    }">
    </div>
    <div class="p-0">
    <h4>${value.title}</h4>
    <p class="text-dark">${value.description || "Khum co description"}</p>
    </div>
    </a>
    `;
  });
  resultArea.innerHTML = html;
}

input.addEventListener("keyup", debounce(getDataWikiAsync, 500));
