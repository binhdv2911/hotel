let input = document.querySelector("#input");
let resultArea = document.querySelector(".result");
const API_SEARCH = `https://en.wikipedia.org/w/api.php?origin=*&action=opensearch&limit=10&format=json&search=`;
const API_THUMBNAIL = `https://en.wikipedia.org/w/api.php?origin=*&action=query&prop=pageprops|pageimages&format=json&titles=`;

function getData(url, callback) {
  let xhr = new XMLHttpRequest();
  xhr.open("GET", url);
  xhr.send();
  xhr.onload = function () {
    if (this.status === 200) {
      callback(undefined, JSON.parse(this.responseText));
    } else {
      callback(new Error(), undefined);
    }
  };
}

function renderData(arr) {
  console.log(arr);
  let html = "";
  arr.map((value) => {
    html += `
      <a href="${value.link}"  class="result__item" target="_blank">
        <div class="p-0 me-3">
          <img src="${
            value.thumbnail ||
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQvNJYG5M1LCfNbTvM6frlwIzRrVM9Vayyk3g-0gXze8EEwGtaFvldLi-QFBSY4kABxlY&usqp=CAU"
          }">
        </div>
        <div class="p-0">
          <h4>${value.title}</h4>
          <p class="text-dark">${value.description || "Khum co description"}</p>
        </div>
      </a>
    `;
  });
  resultArea.innerHTML = html;
}
function getDataWikiCb() {
  getData(`${API_SEARCH}${input.value}`, function (err, titles) {
    if (err) {
      console.error(err);
    } else {
      let result = [];
      let descArr = [];
      let count = 0;

      if (titles[1]) {
        let totalResult = titles[1].length;
        titles[1].map((title) => {
          getData(API_THUMBNAIL + title, function (err, descs) {
            if (err) {
              console.error(err);
            } else {
              count++;
              descArr.push(descs);
              if (count === totalResult) {
                descArr.forEach((value, i) => {
                  let thumbnail =
                    value.query.pages[Object.keys(value.query.pages)].thumbnail
                      ?.source;
                  // console.log(thumbnail);
                  let desc =
                    value.query.pages[Object.keys(value.query.pages)[0]]
                      .pageprops?.["wikibase-shortdesc"];

                  // console.log(desc);
                  result[i] = {
                    thumbnail: thumbnail,
                    description: desc,
                    title: titles[1][i],
                    link: titles[3][i],
                  };
                });

                renderData(result);
              }
            }
          });
        });
      } else {
        renderData(result);
      }
    }
  });
}
input.addEventListener("keyup", debounce(getDataWikiCb, 500));
