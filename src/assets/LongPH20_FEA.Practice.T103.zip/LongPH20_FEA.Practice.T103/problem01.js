function debounce(fn, n) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      fn(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, n);
  };
}

const debounceLog = debounce(console.log, 1000);

debounceLog("abc");
debounceLog("abc");
debounceLog("abc");
